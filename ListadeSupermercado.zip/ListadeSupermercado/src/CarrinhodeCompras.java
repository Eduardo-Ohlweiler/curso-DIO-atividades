import java.util.ArrayList;
import java.util.List;

public class CarrinhodeCompras {
    private List<Item> itemList;

    public CarrinhodeCompras() {
        this.itemList = new ArrayList<>();
    }

    public void adicionarItem(String nome, double preco, int quantidade){
        itemList.add(new Item(nome, preco, quantidade));
    }

    public void removerItem(String nome){
        List<Item> itemParaRemover = new ArrayList<>();
        for(Item I : itemList){
            if(I.getNome().equalsIgnoreCase(nome)){
                itemParaRemover.add(I);
            }
        }
    itemList.removeAll(itemParaRemover);
    }

    public void calcularValorTotal() {
        double total = 0;
        for(Item Q : itemList){
            total += Q.getQuantidade() * Q.getPreco();
        }
        System.out.println("Preço total: " + total);
    }

    public void exibirItens(){
        System.out.println("Lista completa: " + itemList);
    }
}

