// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        CarrinhodeCompras carrinhodeCompras = new CarrinhodeCompras();
        carrinhodeCompras.adicionarItem("caderno", 3.99, 2);
        carrinhodeCompras.adicionarItem("lapis", 0.99, 5);
        carrinhodeCompras.adicionarItem("borracha", 0.99, 2);
        carrinhodeCompras.adicionarItem("tesoura", 1.99, 2);
        carrinhodeCompras.adicionarItem("caneta", 0.99, 3);

        carrinhodeCompras.calcularValorTotal();
        carrinhodeCompras.removerItem("borracha");
        carrinhodeCompras.exibirItens();
        carrinhodeCompras.calcularValorTotal();

    }
}