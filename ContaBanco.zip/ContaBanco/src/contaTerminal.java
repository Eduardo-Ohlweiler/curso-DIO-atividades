import java.util.Scanner;

public class contaTerminal {
    private int numero ;
    private String agencia;
    private String nomeCliente;
    private double saldo;

    public contaTerminal() {
    }

    public contaTerminal(int numero, String agencia, String nomeCliente, double saldo) {
        this.numero = numero;
        this.agencia = agencia;
        this.nomeCliente = nomeCliente;
        this.saldo = saldo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void contaTerminal(){
        Scanner sc = new Scanner(System.in);
        System.out.println("----------------Conta Bancaria----------------");
        System.out.println();
        System.out.println("Por favor, informe o numero da conta: ");
        numero = sc.nextInt();

        System.out.println("Informe o numero de sua agencia: ");
        agencia = sc.next();

        System.out.println("Informe seu nome: ");
        nomeCliente = sc.next();

        System.out.println("Informe o saldo de sua conta: ");
        saldo = sc.nextDouble();

        System.out.println("Olá " + nomeCliente + ", obrigado por criar uma conta em nosso banco," +
                " sua agência é " + agencia +  ", conta " + numero + "e seu saldo de " + saldo +
                " já está disponível para saque");
    }
}
