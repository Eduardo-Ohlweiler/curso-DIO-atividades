/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senac.jogorpg;

/**
 *
 * @author Aluno
 */
public abstract class Personagem {
     private String nome;
     private int vida;
     private int danoAtaque;

    public Personagem(String nome, int vida, int danoAtaque) {
        this.nome = nome;
        this.vida = vida;
        this.danoAtaque = danoAtaque;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public double getDanoAtaque() {
        return danoAtaque;
    }

    public void setDanoAtaque(int danoAtaque) {
        this.danoAtaque = danoAtaque;
    }
     
     
    public void atacar(Personagem vitima){
        if(this.vida <= 0){
            System.out.println("Persongem " + this.nome + "esta morto e não pode atacar");
        } else { 
            vitima.receberAtaque(danoAtaque);  
        }
    }
  
    
    public void receberAtaque(int danoDoAtaque){
        if(this.vida <= 0){
            System.out.println("Persongem " + this.nome + "esta morto");
        } else{
            this.vida -= danoDoAtaque;
            if(vida <= 0){
                this.vida = 0;
                System.out.println("Persongem derrotado");
            }
        }
    }
}
