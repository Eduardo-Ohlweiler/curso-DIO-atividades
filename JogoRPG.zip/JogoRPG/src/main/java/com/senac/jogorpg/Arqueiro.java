/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senac.jogorpg;

/**
 *
 * @author Aluno
 */
public class Arqueiro extends Personagem{
    
    public Arqueiro(String nome, int vida, int danoAtaque) {
        super(nome, vida, danoAtaque);
    }
    
    
    
}
